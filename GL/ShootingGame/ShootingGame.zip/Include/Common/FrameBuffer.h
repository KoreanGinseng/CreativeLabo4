#pragma once
#if defined __GLLIB
#include "../../Framework/Graphics/FrameBuffer.h"
using FrameBuffer = Sample::FrameBuffer;
using FrameBufferPtr = Sample::FrameBufferPtr;
#endif