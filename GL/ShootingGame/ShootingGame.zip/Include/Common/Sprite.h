#pragma once

#if defined __GLLIB
#include    "../../Framework/Graphics/Sprite.h"
using Sprite    = Sample::Sprite;
using SpritePtr = Sample::SpritePtr;
#endif
