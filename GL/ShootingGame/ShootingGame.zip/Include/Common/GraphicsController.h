#pragma once

#if defined __GLLIB
#include "../../Framework/Graphics/GraphicsController.h"
#define GraphicsControllerInstance Sample::GraphicsController::GetInstance()
#endif